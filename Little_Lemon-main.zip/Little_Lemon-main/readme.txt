
Please review the following:

http://127.0.0.1:8000/restaurant/menu/       
http://127.0.0.1:8000/restaurant/menu/2/     (change the id with your newly created ID)
http://127.0.0.1:8000/restaurant/api-token-auth/ (Try Post method!)
http://127.0.0.1:8000/restaurant/booking/ 



Djoser:
http://127.0.0.1:8000/auth/users/   (Remember to try the post method!)
http://127.0.0.1:8000/auth/users/me/
http://127.0.0.1:8000/auth/users/confirm/
http://127.0.0.1:8000/auth/users/resend_activation/
http://127.0.0.1:8000/auth/users/set_password/
http://127.0.0.1:8000/auth/users/reset_password/
http://127.0.0.1:8000/auth/users/reset_password_confirm/
http://127.0.0.1:8000/auth/users/set_username/
http://127.0.0.1:8000/auth/users/reset_username/
http://127.0.0.1:8000/auth/users/reset_username_confirm/

Djoser TOKEN:
http://127.0.0.1:8000/auth/token/login/

